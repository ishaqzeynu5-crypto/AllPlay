# AllPlay — Comprehensive Format & Feature Testing Checklist

Use this checklist before shipping a release to verify universal playback, gestures, subtitles, localization, and performance.

## 1. Container & Codec Matrix

| Category | Test Case | Expected Behavior | Status |
| :--- | :--- | :--- | :---: |
| **MP4** | H.264 + AAC (1080p / 4K) | Plays immediately via HW decoder; smooth seek | [ ] |
| **MKV** | H.265/HEVC (10-bit) + AC3 / EAC3 | HW video + FFmpeg audio (or seamless SW fallback) | [ ] |
| **MKV** | H.264 + DTS / FLAC / OPUS | Audio decodes cleanly via NextLib FFmpeg | [ ] |
| **WebM** | VP8 / VP9 / AV1 + OPUS | Plays via HW or `dav1d` AV1 software decoder | [ ] |
| **AVI** | MPEG-4 / Xvid + MP3 | Extracts and plays with constant-bitrate seeking | [ ] |
| **MOV** | QuickTime H.264 / HEVC | Plays with correct orientation metadata | [ ] |
| **FLV** | Flash Video (H.264 + AAC/MP3) | Opens from storage or file picker without error | [ ] |
| **WMV** | Windows Media Video | Falls back to FFmpeg decoder cleanly | [ ] |
| **3GP** | Legacy mobile recording | Plays smoothly with correct aspect ratio | [ ] |
| **TS / M2TS** | Broadcast MPEG-TS stream | Keyframe seeking works without freeze | [ ] |
| **MPEG / OGV** | MPEG-2 / Theora + Vorbis | Plays via FFmpeg fallback | [ ] |
| **HW -> SW Fallback** | Unsupported codec / 10-bit profile on older GPU | Shows `"This video couldn't play with hardware decoding. Trying another decoder…"` then resumes at exact position in SW mode | [ ] |

## 2. Network Streams & External Intents

- [ ] **HLS (`.m3u8`)**: Paste live or VOD HLS URL in **Open Network URL** dialog -> plays & adapts bitrate.
- [ ] **DASH (`.mpd`)**: Paste MPEG-DASH manifest URL -> plays & exposes audio/subtitle tracks.
- [ ] **RTSP (`rtsp://...`)**: Open IP camera / RTSP test stream -> connects and renders.
- [ ] **Direct HTTP/HTTPS**: Open `.mp4` / `.mkv` direct link -> buffers and seeks cleanly.
- [ ] **Offline / Bad URL**: Verify friendly error message (`"Unable to reach this video link..."`) + working **Retry** button.
- [ ] **"Open with" from File Manager / Telegram / WhatsApp**: Tap any video in another app -> choose **AllPlay** -> launches straight into `PlayerScreen`.
- [ ] **System File Picker**: Tap folder-open icon on Home -> pick a video from SD card or Downloads -> plays immediately.

## 3. Player Controls, Gestures & Background Modes

- [ ] **Swipe Left/Right**: Seeks smoothly with center time HUD.
- [ ] **Swipe Up/Down (Left Half)**: Adjusts window brightness `2%–100%` without affecting system-wide setting after exit.
- [ ] **Swipe Up/Down (Right Half)**: Adjusts media volume `0%–100%` with HUD.
- [ ] **Double-Tap Left / Right**: Skips `-10s` / `+10s` with visual HUD.
- [ ] **Pinch to Zoom**: Zooms `100%–300%` smoothly.
- [ ] **Screen Lock**: Disables all gestures and hides controls except the single Unlock button.
- [ ] **Rotation Lock**: Cycles Auto -> Landscape -> Portrait cleanly without restarting playback.
- [ ] **Playback Speed**: Test `0.25x`, `1.0x`, `2.0x`, `4.0x` -> audio pitch stays clear; speed saved per video.
- [ ] **Aspect Ratio**: Test **Fit**, **Fill**, **Stretch**, and **16:9**.
- [ ] **Remember Position**: Exit midway through a video -> verify it appears in **Continue Watching** with progress bar and resumes at the saved timestamp.
- [ ] **Picture-in-Picture (PiP)**: Tap PiP icon or press Home while playing -> video shrinks to floating window without controls clutter.
- [ ] **Background Audio**: Enable headphones toggle -> lock screen -> audio continues with notification controls (`PlaybackService`).
- [ ] **Sleep Timer**: Set 15m or **End of video** -> playback pauses automatically when timer fires.

## 4. Subtitles & Audio Tracks

- [ ] **Auto-Detect**: Place `Movie.srt` (or `Movie.en.srt`) next to `Movie.mkv` -> automatically loaded.
- [ ] **Manual Load**: Pick external `.srt`, `.ass`, `.ssa`, or `.vtt` from phone storage -> renders immediately.
- [ ] **Embedded Subtitles & Multi-Audio**: Switch between embedded audio languages and subtitle tracks in the Tracks sheet.
- [ ] **Subtitle Styling & Delay**: Adjust font size (`14sp–32sp`), text color, background opacity, and `-0.5s / +0.5s` delay.

## 5. Ease of Use, Localization, Accessibility & Scale

- [ ] **First-Launch Tutorial**: Fresh install shows 3 gesture screens; Skip/Start saves state; replayable from Settings.
- [ ] **English & Amharic (`አማርኛ`)**: Switch language in Settings -> all tabs, dialogs, error messages, and player labels update immediately.
- [ ] **Dark & Light Themes**: Toggle System / Light / Dark -> verify contrast and readability.
- [ ] **TalkBack**: Enable Android TalkBack -> navigate Home cards, tabs, and Player controls; verify every button announces a clear label.
- [ ] **10,000+ Videos Performance**: Verify `LazyColumn` / `LazyVerticalGrid` scroll stays 60fps with Coil 3 disk/memory thumbnail caching.
