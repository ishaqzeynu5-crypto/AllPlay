# Keep Media3 and NextLib FFmpeg native JNI bridges intact
-keep class androidx.media3.** { *; }
-keep class io.github.anilbeesetti.nextlib.** { *; }
-dontwarn io.github.anilbeesetti.nextlib.**

# Keep Room entities & DAOs
-keep class com.allplay.video.data.local.** { *; }
