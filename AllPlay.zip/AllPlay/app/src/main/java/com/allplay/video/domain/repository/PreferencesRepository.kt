package com.allplay.video.domain.repository

import com.allplay.video.domain.model.*
import kotlinx.coroutines.flow.Flow

interface PreferencesRepository {
    val userPreferences: Flow<UserPreferences>
    suspend fun setOnboardingCompleted(completed: Boolean)
    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setLanguage(language: AppLanguage)
    suspend fun setSort(option: SortOption, order: SortOrder)
    suspend fun setViewMode(mode: ViewMode)
    suspend fun setDecoderMode(mode: DecoderMode)
    suspend fun setBackgroundAudioEnabled(enabled: Boolean)
    suspend fun updateSubtitleStyle(style: SubtitleStyle)
}
