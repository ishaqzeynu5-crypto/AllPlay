package com.allplay.video.domain.model

/**
 * Core domain model representing a playable local or network video.
 */
data class VideoItem(
    val id: Long,
    val uri: String,
    val title: String,
    val displayName: String,
    val folderName: String,
    val folderPath: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val width: Int = 0,
    val height: Int = 0,
    val mimeType: String = "video/*",
    val lastPositionMs: Long = 0L,
    val lastPlayedAt: Long = 0L
) {
    /** Progress fraction in [0f, 1f] for Continue Watching progress bars. */
    val watchProgress: Float
        get() = if (durationMs > 0L) {
            (lastPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f

    val isInProgress: Boolean
        get() = lastPositionMs > 5_000L && watchProgress < 0.95f
}

/**
 * Grouped folder view for the "Folders" tab.
 */
data class VideoFolder(
    val name: String,
    val path: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val previewUri: String
)

enum class SortOption { NAME, DATE, SIZE, DURATION }
enum class SortOrder { ASCENDING, DESCENDING }
enum class ViewMode { LIST, GRID }
enum class AspectRatioMode { FIT, FILL, STRETCH, RATIO_16_9 }
enum class DecoderMode { AUTO_HW_FIRST, SOFTWARE_FFMPEG }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class AppLanguage(val tag: String) { ENGLISH("en"), AMHARIC("am") }
