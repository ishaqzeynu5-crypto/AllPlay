package com.allplay.video.ui.player.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.allplay.video.R
import com.allplay.video.domain.model.AspectRatioMode
import com.allplay.video.domain.model.SubtitleStyle
import com.allplay.video.domain.model.TrackInfo
import com.allplay.video.player.SleepTimerState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeedBottomSheet(
    currentSpeed: Float,
    onSelectSpeed: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f)
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            Text(stringResource(R.string.speed_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            speeds.chunked(3).forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row.forEach { speed ->
                        val selected = kotlin.math.abs(currentSpeed - speed) < 0.02f
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectSpeed(speed); onDismiss() },
                            label = { Text("${speed}x") },
                            modifier = Modifier.weight(1f).height(48.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AspectRatioBottomSheet(
    currentMode: AspectRatioMode,
    onSelectMode: (AspectRatioMode) -> Unit,
    onDismiss: () -> Unit
) {
    val modes = listOf(
        AspectRatioMode.FIT to R.string.aspect_fit,
        AspectRatioMode.FILL to R.string.aspect_fill,
        AspectRatioMode.STRETCH to R.string.aspect_stretch,
        AspectRatioMode.RATIO_16_9 to R.string.aspect_16_9
    )
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            Text(stringResource(R.string.aspect_ratio_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            modes.forEach { (mode, labelRes) ->
                ListItem(
                    headlineContent = { Text(stringResource(labelRes), style = MaterialTheme.typography.bodyLarge) },
                    trailingContent = {
                        if (currentMode == mode) Icon(Icons.Rounded.Check, contentDescription = null)
                    },
                    modifier = Modifier.clickable { onSelectMode(mode); onDismiss() }
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioSubtitleBottomSheet(
    audioTracks: List<TrackInfo>,
    subtitleTracks: List<TrackInfo>,
    subtitleStyle: SubtitleStyle,
    onSelectAudio: (Int, Int) -> Unit,
    onSelectSubtitle: (Int?, Int?) -> Unit,
    onPickExternalSubtitle: () -> Unit,
    onUpdateSubtitleStyle: (SubtitleStyle) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            Text(stringResource(R.string.audio_tracks_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (audioTracks.isEmpty()) {
                Text("Default", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
            } else {
                audioTracks.forEach { track ->
                    ListItem(
                        headlineContent = { Text(track.label) },
                        supportingContent = track.language?.let { { Text(it) } },
                        trailingContent = { if (track.isSelected) Icon(Icons.Rounded.Check, null) },
                        modifier = Modifier.clickable { onSelectAudio(track.groupIndex, track.trackIndex) }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.subtitles_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            OutlinedButton(
                onClick = onPickExternalSubtitle,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Rounded.Subtitles, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.load_subtitle_file))
            }

            ListItem(
                headlineContent = { Text(stringResource(R.string.subtitles_off)) },
                trailingContent = {
                    if (subtitleTracks.none { it.isSelected }) Icon(Icons.Rounded.Check, null)
                },
                modifier = Modifier.clickable { onSelectSubtitle(null, null) }
            )
            subtitleTracks.forEach { track ->
                ListItem(
                    headlineContent = { Text(track.label) },
                    supportingContent = track.language?.let { { Text(it) } },
                    trailingContent = { if (track.isSelected) Icon(Icons.Rounded.Check, null) },
                    modifier = Modifier.clickable { onSelectSubtitle(track.groupIndex, track.trackIndex) }
                )
            }

            Spacer(Modifier.height(16.dp))
            // Subtitle delay control (-10s to +10s)
            val delaySec = subtitleStyle.delayMs / 1000f
            Text(
                "${stringResource(R.string.subtitle_delay)}: ${String.format(Locale.US, "%+.2fs", delaySec)}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onUpdateSubtitleStyle(subtitleStyle.copy(delayMs = subtitleStyle.delayMs - 500L)) },
                    modifier = Modifier.weight(1f)
                ) { Text("-0.5s") }
                OutlinedButton(
                    onClick = { onUpdateSubtitleStyle(subtitleStyle.copy(delayMs = 0L)) },
                    modifier = Modifier.weight(1f)
                ) { Text("0s") }
                OutlinedButton(
                    onClick = { onUpdateSubtitleStyle(subtitleStyle.copy(delayMs = subtitleStyle.delayMs + 500L)) },
                    modifier = Modifier.weight(1f)
                ) { Text("+0.5s") }
            }

            // Font size slider (14sp - 32sp)
            Text(
                "${stringResource(R.string.subtitle_size)}: ${subtitleStyle.fontSizeSp.toInt()}sp",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Slider(
                value = subtitleStyle.fontSizeSp,
                onValueChange = { onUpdateSubtitleStyle(subtitleStyle.copy(fontSizeSp = it)) },
                valueRange = 14f..32f
            )

            // Text colors
            Text(stringResource(R.string.subtitle_color), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            val textColors = listOf(
                0xFFFFFFFF.toInt(), // White
                0xFFFFEB3B.toInt(), // Yellow
                0xFF22D3EE.toInt(), // Cyan
                0xFF4ADE80.toInt()  // Green
            )
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                textColors.forEach { argb ->
                    val selected = subtitleStyle.textColorArgb == argb
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(argb))
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                shape = CircleShape
                            )
                            .clickable { onUpdateSubtitleStyle(subtitleStyle.copy(textColorArgb = argb)) }
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            // Background opacity choices
            Text(stringResource(R.string.subtitle_background), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            val bgChoices = listOf(
                0x00000000 to "None",
                0x80000000.toInt() to "50%",
                0xE6000000.toInt() to "Solid"
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                bgChoices.forEach { (bgArgb, label) ->
                    FilterChip(
                        selected = subtitleStyle.backgroundColorArgb == bgArgb,
                        onClick = { onUpdateSubtitleStyle(subtitleStyle.copy(backgroundColorArgb = bgArgb)) },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepTimerBottomSheet(
    currentState: SleepTimerState,
    onSelectMinutes: (Int) -> Unit,
    onSelectEndOfVideo: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            Text(stringResource(R.string.sleep_timer_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            ListItem(
                headlineContent = { Text(stringResource(R.string.sleep_timer_off)) },
                trailingContent = { if (currentState is SleepTimerState.Off) Icon(Icons.Rounded.Check, null) },
                modifier = Modifier.clickable { onSelectMinutes(0); onDismiss() }
            )
            listOf(15, 30, 45, 60).forEach { mins ->
                ListItem(
                    headlineContent = { Text(stringResource(R.string.sleep_timer_minutes, mins)) },
                    modifier = Modifier.clickable { onSelectMinutes(mins); onDismiss() }
                )
            }
            ListItem(
                headlineContent = { Text(stringResource(R.string.sleep_timer_end_of_video)) },
                trailingContent = { if (currentState is SleepTimerState.EndOfVideo) Icon(Icons.Rounded.Check, null) },
                modifier = Modifier.clickable { onSelectEndOfVideo(); onDismiss() }
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}
