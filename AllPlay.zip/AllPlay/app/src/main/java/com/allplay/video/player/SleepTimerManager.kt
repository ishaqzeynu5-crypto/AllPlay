package com.allplay.video.player

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface SleepTimerState {
    data object Off : SleepTimerState
    data object EndOfVideo : SleepTimerState
    data class CountingDown(val remainingMs: Long) : SleepTimerState
}

/**
 * Manages the sleep timer countdown (15m, 30m, 45m, 60m, or End of Video).
 */
class SleepTimerManager(private val scope: CoroutineScope) {
    private val _state = MutableStateFlow<SleepTimerState>(SleepTimerState.Off)
    val state: StateFlow<SleepTimerState> = _state.asStateFlow()

    private var timerJob: Job? = null

    fun startMinutes(minutes: Int, onExpire: () -> Unit) {
        cancel()
        if (minutes <= 0) return
        val totalMs = minutes * 60_000L
        timerJob = scope.launch {
            var remaining = totalMs
            while (remaining > 0L) {
                _state.value = SleepTimerState.CountingDown(remaining)
                delay(1_000L)
                remaining -= 1_000L
            }
            _state.value = SleepTimerState.Off
            onExpire()
        }
    }

    fun setEndOfVideo() {
        cancel()
        _state.value = SleepTimerState.EndOfVideo
    }

    fun cancel() {
        timerJob?.cancel()
        timerJob = null
        _state.value = SleepTimerState.Off
    }
}
