package com.allplay.video.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persists watch history, exact resume position, and per-video playback speed.
 */
@Entity(tableName = "playback_history")
data class PlaybackHistoryEntity(
    @PrimaryKey val uri: String,
    val title: String,
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayedAt: Long,
    val playbackSpeed: Float = 1.0f
)
