package com.allplay.video.domain.repository

import com.allplay.video.domain.model.VideoFolder
import com.allplay.video.domain.model.VideoItem
import kotlinx.coroutines.flow.Flow

interface VideoRepository {
    fun observeAllVideos(): Flow<List<VideoItem>>
    fun observeContinueWatching(): Flow<List<VideoItem>>
    fun observeRecentVideos(): Flow<List<VideoItem>>
    fun observeFolders(): Flow<List<VideoFolder>>
    suspend fun refreshLibrary()
    suspend fun getSavedPosition(uri: String): Long
    suspend fun savePlaybackProgress(
        uri: String,
        title: String,
        positionMs: Long,
        durationMs: Long,
        playbackSpeed: Float
    )
    suspend fun getSavedSpeed(uri: String): Float
}
