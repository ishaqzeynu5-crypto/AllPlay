package com.allplay.video.ui.home

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.allplay.video.R
import com.allplay.video.domain.model.VideoItem
import com.allplay.video.domain.model.ViewMode
import com.allplay.video.ui.home.components.*

/**
 * Simple, one-handed-friendly Home screen with bottom navigation tabs for
 * Videos, Folders, and Recent, a Continue Watching strip, Search, Sort, Grid/List toggle,
 * Network URL dialog, and System File Picker.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onPlayVideo: (VideoItem, List<VideoItem>) -> Unit,
    onPlayUri: (uri: String, title: String) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    val mediaPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, mediaPermission) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (granted) viewModel.refreshLibrary()
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onPlayUri(uri.toString(), uri.lastPathSegment ?: "Video")
        }
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) viewModel.refreshLibrary()
    }

    var showSortSheet by remember { mutableStateOf(false) }
    var showUrlDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.app_name),
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = { showUrlDialog = true }) {
                        Icon(Icons.Rounded.Link, contentDescription = stringResource(R.string.open_url))
                    }
                    IconButton(onClick = { filePickerLauncher.launch(arrayOf("video/*", "*/*")) }) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = stringResource(R.string.open_file))
                    }
                    IconButton(onClick = { viewModel.toggleViewMode() }) {
                        Icon(
                            imageVector = if (state.viewMode == ViewMode.LIST) Icons.Rounded.GridView
                            else Icons.AutoMirrored.Rounded.ViewList,
                            contentDescription = stringResource(
                                if (state.viewMode == ViewMode.LIST) R.string.switch_to_grid else R.string.switch_to_list
                            )
                        )
                    }
                    IconButton(onClick = { showSortSheet = true }) {
                        Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = stringResource(R.string.sort_by))
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Rounded.Settings, contentDescription = stringResource(R.string.settings))
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = state.selectedTab == HomeTab.VIDEOS,
                    onClick = { viewModel.selectTab(HomeTab.VIDEOS) },
                    icon = { Icon(Icons.Rounded.VideoLibrary, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_videos)) }
                )
                NavigationBarItem(
                    selected = state.selectedTab == HomeTab.FOLDERS,
                    onClick = { viewModel.selectTab(HomeTab.FOLDERS) },
                    icon = { Icon(Icons.Rounded.Folder, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_folders)) }
                )
                NavigationBarItem(
                    selected = state.selectedTab == HomeTab.RECENT,
                    onClick = { viewModel.selectTab(HomeTab.RECENT) },
                    icon = { Icon(Icons.Rounded.History, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_recent)) }
                )
            }
        }
    ) { padding ->
        if (!hasPermission) {
            Box(Modifier.padding(padding)) {
                PermissionRationaleCard(onRequestPermission = { permissionLauncher.launch(mediaPermission) })
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search bar
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = viewModel::updateSearch,
                placeholder = { Text(stringResource(R.string.search_videos_hint)) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearch("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.extraLarge,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )

            // Back bar when browsing inside a folder
            if (state.selectedTab == HomeTab.FOLDERS && state.selectedFolderPath != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { viewModel.openFolder(null) }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.back_to_folders))
                    }
                }
            }

            when {
                state.selectedTab == HomeTab.FOLDERS && state.selectedFolderPath == null -> {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(state.folders, key = { it.path }) { folder ->
                            FolderRow(
                                folder = folder,
                                onClick = { viewModel.openFolder(folder.path) }
                            )
                        }
                    }
                }

                else -> {
                    val displayedList = if (state.selectedTab == HomeTab.RECENT) state.recentVideos else state.videos
                    if (displayedList.isEmpty() && !state.isLoading) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = stringResource(
                                    if (state.selectedTab == HomeTab.RECENT) R.string.no_recent_videos
                                    else R.string.no_videos_found
                                ),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else if (state.viewMode == ViewMode.GRID) {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 164.dp),
                            contentPadding = PaddingValues(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(displayedList, key = { it.uri }) { video ->
                                VideoGridCard(
                                    video = video,
                                    onClick = { onPlayVideo(video, displayedList) }
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (state.selectedTab == HomeTab.VIDEOS &&
                                state.continueWatching.isNotEmpty() &&
                                state.searchQuery.isBlank()
                            ) {
                                item(key = "continue_watching_header") {
                                    Text(
                                        text = stringResource(R.string.continue_watching),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.padding(bottom = 16.dp)
                                    ) {
                                        items(state.continueWatching, key = { "cw_${it.uri}" }) { item ->
                                            ContinueWatchingCard(
                                                video = item,
                                                onClick = { onPlayVideo(item, state.videos) }
                                            )
                                        }
                                    }
                                }
                            }
                            items(displayedList, key = { it.uri }) { video ->
                                VideoListRow(
                                    video = video,
                                    onClick = { onPlayVideo(video, displayedList) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSortSheet) {
        SortBottomSheet(
            currentOption = state.sortOption,
            currentOrder = state.sortOrder,
            onSelect = { opt, ord -> viewModel.setSort(opt, ord) },
            onDismiss = { showSortSheet = false }
        )
    }

    if (showUrlDialog) {
        NetworkUrlDialog(
            onDismiss = { showUrlDialog = false },
            onPlayUrl = { url ->
                showUrlDialog = false
                onPlayUri(url, url.substringAfterLast('/').ifBlank { "Network Stream" })
            }
        )
    }
}
