package com.allplay.video.di

import android.content.Context
import androidx.room.Room
import com.allplay.video.data.local.AllPlayDatabase
import com.allplay.video.data.local.PlaybackHistoryDao
import com.allplay.video.data.preferences.PreferencesRepositoryImpl
import com.allplay.video.data.repository.VideoRepositoryImpl
import com.allplay.video.domain.repository.PreferencesRepository
import com.allplay.video.domain.repository.VideoRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AllPlayDatabase =
        Room.databaseBuilder(context, AllPlayDatabase::class.java, "allplay.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun providePlaybackHistoryDao(db: AllPlayDatabase): PlaybackHistoryDao =
        db.playbackHistoryDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindVideoRepository(impl: VideoRepositoryImpl): VideoRepository

    @Binds
    @Singleton
    abstract fun bindPreferencesRepository(impl: PreferencesRepositoryImpl): PreferencesRepository
}
