package com.allplay.video.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF4F46E5)
val IndigoLight = Color(0xFF818CF8)
val TealAccent = Color(0xFF14B8A6)
val AmberHighlight = Color(0xFFF59E0B)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightOnSurface = Color(0xFF0F172A)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131926)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF1F5F9)
