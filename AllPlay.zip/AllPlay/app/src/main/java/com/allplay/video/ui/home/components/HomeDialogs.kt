package com.allplay.video.ui.home.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.allplay.video.R
import com.allplay.video.domain.model.SortOption
import com.allplay.video.domain.model.SortOrder

@Composable
fun PermissionRationaleCard(onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Rounded.VideoLibrary,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(20.dp))
        Text(
            text = stringResource(R.string.permission_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.permission_message),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onRequestPermission,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) {
            Text(stringResource(R.string.permission_button), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
fun NetworkUrlDialog(
    onDismiss: () -> Unit,
    onPlayUrl: (String) -> Unit
) {
    var url by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.url_dialog_title)) },
        text = {
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                placeholder = { Text(stringResource(R.string.url_dialog_hint)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = url.trim()
                    if (trimmed.isNotBlank()) onPlayUrl(trimmed)
                },
                enabled = url.isNotBlank()
            ) {
                Text(stringResource(R.string.play_now))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SortBottomSheet(
    currentOption: SortOption,
    currentOrder: SortOrder,
    onSelect: (SortOption, SortOrder) -> Unit,
    onDismiss: () -> Unit
) {
    var option by remember { mutableStateOf(currentOption) }
    var order by remember { mutableStateOf(currentOrder) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = stringResource(R.string.sort_by),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))

            val options = listOf(
                SortOption.NAME to R.string.sort_name,
                SortOption.DATE to R.string.sort_date,
                SortOption.SIZE to R.string.sort_size,
                SortOption.DURATION to R.string.sort_duration
            )
            options.forEach { (sortOpt, labelRes) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = option == sortOpt,
                        onClick = {
                            option = sortOpt
                            onSelect(option, order)
                        }
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(labelRes), style = MaterialTheme.typography.bodyLarge)
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FilterChip(
                    selected = order == SortOrder.ASCENDING,
                    onClick = {
                        order = SortOrder.ASCENDING
                        onSelect(option, order)
                    },
                    label = { Text(stringResource(R.string.sort_ascending)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = order == SortOrder.DESCENDING,
                    onClick = {
                        order = SortOrder.DESCENDING
                        onSelect(option, order)
                    },
                    label = { Text(stringResource(R.string.sort_descending)) },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
