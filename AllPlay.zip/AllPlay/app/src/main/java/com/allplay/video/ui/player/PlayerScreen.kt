package com.allplay.video.ui.player

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.allplay.video.R
import com.allplay.video.domain.model.AspectRatioMode
import com.allplay.video.domain.model.DecoderMode
import com.allplay.video.player.SleepTimerState
import com.allplay.video.player.SubtitleStyleHelper
import com.allplay.video.ui.home.components.formatDuration
import com.allplay.video.ui.player.components.*
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

private enum class ActiveSheet { NONE, SPEED, ASPECT, TRACKS, SLEEP }
private enum class GestureMode { NONE, SEEK, BRIGHTNESS, VOLUME }

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    viewModel: PlayerViewModel,
    isInPipMode: Boolean,
    onEnterPip: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val player by viewModel.playerFlow.collectAsStateWithLifecycle()

    var showControls by remember { mutableStateOf(true) }
    var activeSheet by remember { mutableStateOf(ActiveSheet.NONE) }
    var videoZoomScale by remember { mutableFloatStateOf(1f) }
    var viewportSize by remember { mutableStateOf(IntSize.Zero) }
    var hudText by remember { mutableStateOf<String?>(null) }

    // Rotation lock cycle: Sensor -> Landscape -> Portrait
    var orientationIndex by remember { mutableIntStateOf(0) }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }

    // Subtitle file picker (.srt, .ass, .ssa, .vtt)
    val subtitlePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.addExternalSubtitle(uri)
    }

    // Hide system bars for immersive playback; restore on exit
    DisposableEffect(Unit) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Handle pause/background audio when app leaves foreground
    DisposableEffect(lifecycleOwner, isInPipMode) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                viewModel.onAppBackgrounded(isInPip = isInPipMode)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Auto-hide controls after 4 seconds while playing
    LaunchedEffect(showControls, state.isPlaying, activeSheet) {
        if (showControls && state.isPlaying && activeSheet == ActiveSheet.NONE) {
            delay(4_000L)
            showControls = false
        }
    }

    // Auto-clear gesture HUD after 1.2s
    LaunchedEffect(hudText) {
        if (hudText != null) {
            delay(1_200L)
            hudText = null
        }
    }

    val brightnessLabel = stringResource(R.string.brightness_label)
    val volumeLabel = stringResource(R.string.volume_label)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { viewportSize = it }
            // Pinch-to-zoom (1x to 3x)
            .pointerInput(state.isScreenLocked) {
                if (state.isScreenLocked) return@pointerInput
                detectTransformGestures { _, _, zoom, _ ->
                    if (abs(zoom - 1f) > 0.01f) {
                        videoZoomScale = (videoZoomScale * zoom).coerceIn(1f, 3f)
                        hudText = "${(videoZoomScale * 100).roundToInt()}%"
                    }
                }
            }
            // Tap to toggle controls, double-tap left/right to skip -10s / +10s
            .pointerInput(state.isScreenLocked, viewportSize) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { offset ->
                        if (state.isScreenLocked) return@detectTapGestures
                        val isRight = offset.x > viewportSize.width / 2f
                        if (isRight) {
                            viewModel.seekBy(10_000L)
                            hudText = "+10s"
                        } else {
                            viewModel.seekBy(-10_000L)
                            hudText = "-10s"
                        }
                    }
                )
            }
            // Swipe horizontal to seek; vertical left for brightness; vertical right for volume
            .pointerInput(state.isScreenLocked, viewportSize) {
                if (state.isScreenLocked) return@pointerInput
                var gestureMode = GestureMode.NONE
                var startX = 0f
                var seekStartPos = 0L
                var brightnessLevel = activity?.window?.attributes?.screenBrightness
                    ?.takeIf { it >= 0f } ?: 0.5f
                var volumeLevel = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume

                detectDragGestures(
                    onDragStart = { offset ->
                        gestureMode = GestureMode.NONE
                        startX = offset.x
                        seekStartPos = state.currentPositionMs
                        brightnessLevel = activity?.window?.attributes?.screenBrightness
                            ?.takeIf { it >= 0f } ?: 0.5f
                        volumeLevel = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
                    },
                    onDragEnd = { gestureMode = GestureMode.NONE },
                    onDragCancel = { gestureMode = GestureMode.NONE },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        if (gestureMode == GestureMode.NONE) {
                            gestureMode = if (abs(dragAmount.x) > abs(dragAmount.y)) {
                                GestureMode.SEEK
                            } else if (startX < viewportSize.width / 2f) {
                                GestureMode.BRIGHTNESS
                            } else {
                                GestureMode.VOLUME
                            }
                        }

                        when (gestureMode) {
                            GestureMode.SEEK -> {
                                val deltaMs = (dragAmount.x * 120f).toLong()
                                seekStartPos = (seekStartPos + deltaMs).coerceIn(0L, state.durationMs.coerceAtLeast(1L))
                                viewModel.seekTo(seekStartPos)
                                hudText = formatDuration(seekStartPos)
                            }
                            GestureMode.BRIGHTNESS -> {
                                val delta = -dragAmount.y / viewportSize.height.coerceAtLeast(1)
                                brightnessLevel = (brightnessLevel + delta * 1.4f).coerceIn(0.02f, 1.0f)
                                activity?.window?.let { win ->
                                    val lp = win.attributes
                                    lp.screenBrightness = brightnessLevel
                                    win.attributes = lp
                                }
                                hudText = "$brightnessLabel ${(brightnessLevel * 100).roundToInt()}%"
                            }
                            GestureMode.VOLUME -> {
                                val delta = -dragAmount.y / viewportSize.height.coerceAtLeast(1)
                                volumeLevel = (volumeLevel + delta * 1.4f).coerceIn(0f, 1f)
                                val targetVol = (volumeLevel * maxVolume).roundToInt()
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                                hudText = "$volumeLabel ${(volumeLevel * 100).roundToInt()}%"
                            }
                            GestureMode.NONE -> Unit
                        }
                    }
                )
            }
    ) {
        // Video Surface via Media3 PlayerView
        val videoModifier = when (state.aspectRatioMode) {
            AspectRatioMode.RATIO_16_9 -> Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
            else -> Modifier.fillMaxSize()
        }.graphicsLayer(scaleX = videoZoomScale, scaleY = videoZoomScale)

        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    keepScreenOn = true
                }
            },
            update = { view ->
                if (view.player !== player) {
                    view.player = player
                }
                view.resizeMode = when (state.aspectRatioMode) {
                    AspectRatioMode.FIT, AspectRatioMode.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    AspectRatioMode.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                }
                SubtitleStyleHelper.applyTo(view.subtitleView, state.subtitleStyle)
            },
            modifier = videoModifier
        )

        // Buffering spinner
        if (state.isBuffering) {
            CircularProgressIndicator(
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Gesture HUD Pill (Seek / Volume / Brightness / Zoom)
        hudText?.let { text ->
            Surface(
                color = Color.Black.copy(alpha = 0.78f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = text,
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp)
                )
            }
        }

        // Friendly Status Banner (e.g., "This video couldn't play. Trying another decoder...")
        state.statusBannerRes?.let { resId ->
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 64.dp, start = 20.dp, end = 20.dp)
            ) {
                Text(
                    text = stringResource(resId),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
        }

        // Friendly Error Card with Retry
        state.errorBannerRes?.let { resId ->
            Card(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(resId),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = viewModel::retryPlayback) {
                        Text(stringResource(R.string.retry))
                    }
                }
            }
        }

        // Controls Overlay (hidden in PiP mode)
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                if (state.isScreenLocked) {
                    // Screen Locked mode: only show a single accessible Unlock button
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                        FilledTonalIconButton(
                            onClick = viewModel::toggleScreenLock,
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .size(56.dp)
                                .semantics { contentDescription = context.getString(R.string.cd_unlock_screen) }
                        ) {
                            Icon(Icons.Rounded.LockOpen, contentDescription = null)
                        }
                    }
                } else {
                    PlayerControlsOverlay(
                        state = state,
                        onBack = {
                            viewModel.saveCurrentProgress()
                            onBack()
                        },
                        onTogglePlayPause = viewModel::togglePlayPause,
                        onNext = viewModel::playNext,
                        onPrevious = viewModel::playPrevious,
                        onSeek = viewModel::seekTo,
                        onToggleLock = viewModel::toggleScreenLock,
                        onRotate = {
                            orientationIndex = (orientationIndex + 1) % 3
                            activity?.requestedOrientation = when (orientationIndex) {
                                1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                2 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            }
                        },
                        onEnterPip = onEnterPip,
                        onToggleBgAudio = viewModel::toggleBackgroundAudio,
                        onToggleDecoder = {
                            val next = if (state.decoderMode == DecoderMode.AUTO_HW_FIRST) {
                                DecoderMode.SOFTWARE_FFMPEG
                            } else {
                                DecoderMode.AUTO_HW_FIRST
                            }
                            viewModel.switchDecoderManually(next)
                        },
                        onOpenSpeed = { activeSheet = ActiveSheet.SPEED },
                        onOpenAspect = { activeSheet = ActiveSheet.ASPECT },
                        onOpenTracks = { activeSheet = ActiveSheet.TRACKS },
                        onOpenSleepTimer = { activeSheet = ActiveSheet.SLEEP }
                    )
                }
            }
        }
    }

    // Modal Bottom Sheets
    when (activeSheet) {
        ActiveSheet.SPEED -> SpeedBottomSheet(
            currentSpeed = state.playbackSpeed,
            onSelectSpeed = viewModel::setPlaybackSpeed,
            onDismiss = { activeSheet = ActiveSheet.NONE }
        )
        ActiveSheet.ASPECT -> AspectRatioBottomSheet(
            currentMode = state.aspectRatioMode,
            onSelectMode = viewModel::setAspectRatio,
            onDismiss = { activeSheet = ActiveSheet.NONE }
        )
        ActiveSheet.TRACKS -> AudioSubtitleBottomSheet(
            audioTracks = state.audioTracks,
            subtitleTracks = state.subtitleTracks,
            subtitleStyle = state.subtitleStyle,
            onSelectAudio = viewModel::selectAudioTrack,
            onSelectSubtitle = viewModel::selectSubtitleTrack,
            onPickExternalSubtitle = { subtitlePicker.launch(arrayOf("*/*")) },
            onUpdateSubtitleStyle = viewModel::updateSubtitleStyle,
            onDismiss = { activeSheet = ActiveSheet.NONE }
        )
        ActiveSheet.SLEEP -> SleepTimerBottomSheet(
            currentState = state.sleepTimerState,
            onSelectMinutes = viewModel::setSleepTimerMinutes,
            onSelectEndOfVideo = viewModel::setSleepTimerEndOfVideo,
            onDismiss = { activeSheet = ActiveSheet.NONE }
        )
        ActiveSheet.NONE -> Unit
    }
}

@Composable
private fun PlayerControlsOverlay(
    state: PlayerUiState,
    onBack: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleLock: () -> Unit,
    onRotate: () -> Unit,
    onEnterPip: () -> Unit,
    onToggleBgAudio: () -> Unit,
    onToggleDecoder: () -> Unit,
    onOpenSpeed: () -> Unit,
    onOpenAspect: () -> Unit,
    onOpenTracks: () -> Unit,
    onOpenSleepTimer: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = 0.72f),
                        Color.Transparent,
                        Color.Transparent,
                        Color.Black.copy(alpha = 0.80f)
                    )
                )
            )
            .systemBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Bar: Back, Title, Decoder badge, PiP, Background Audio, Sleep Timer
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.cd_back), tint = Color.White)
            }
            Text(
                text = state.title,
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            AssistChip(
                onClick = onToggleDecoder,
                label = {
                    Text(
                        text = if (state.isUsingSoftwareFallback) "SW" else "HW",
                        color = Color.White
                    )
                }
            )
            IconButton(onClick = onToggleBgAudio, modifier = Modifier.size(48.dp)) {
                Icon(
                    imageVector = Icons.Rounded.Headphones,
                    contentDescription = stringResource(R.string.cd_background_audio),
                    tint = if (state.backgroundAudioEnabled) MaterialTheme.colorScheme.primary else Color.White
                )
            }
            IconButton(onClick = onOpenSleepTimer, modifier = Modifier.size(48.dp)) {
                Icon(
                    imageVector = Icons.Rounded.Bedtime,
                    contentDescription = stringResource(R.string.sleep_timer_title),
                    tint = if (state.sleepTimerState !is SleepTimerState.Off) MaterialTheme.colorScheme.primary else Color.White
                )
            }
            IconButton(onClick = onEnterPip, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = stringResource(R.string.cd_pip), tint = Color.White)
            }
        }

        // Center Large Transport Controls (Easy to tap)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onPrevious,
                enabled = state.hasPrevious,
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    Icons.Rounded.SkipPrevious,
                    contentDescription = stringResource(R.string.cd_previous),
                    tint = if (state.hasPrevious) Color.White else Color.White.copy(alpha = 0.35f),
                    modifier = Modifier.size(40.dp)
                )
            }

            IconButton(
                onClick = onTogglePlayPause,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.22f))
            ) {
                Icon(
                    imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = stringResource(if (state.isPlaying) R.string.cd_pause else R.string.cd_play),
                    tint = Color.White,
                    modifier = Modifier.size(46.dp)
                )
            }

            IconButton(
                onClick = onNext,
                enabled = state.hasNext,
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    Icons.Rounded.SkipNext,
                    contentDescription = stringResource(R.string.cd_next),
                    tint = if (state.hasNext) Color.White else Color.White.copy(alpha = 0.35f),
                    modifier = Modifier.size(40.dp)
                )
            }
        }

        // Bottom Bar: Seekbar + Action Controls
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(formatDuration(state.currentPositionMs), color = Color.White, style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = state.currentPositionMs.toFloat(),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..state.durationMs.coerceAtLeast(1L).toFloat(),
                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                )
                Text(formatDuration(state.durationMs), color = Color.White, style = MaterialTheme.typography.labelLarge)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onToggleLock, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Lock, contentDescription = stringResource(R.string.cd_lock_screen), tint = Color.White)
                }
                TextButton(onClick = onOpenSpeed) {
                    Text("${state.playbackSpeed}x", color = Color.White, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onOpenTracks, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Subtitles, contentDescription = stringResource(R.string.subtitles_title), tint = Color.White)
                }
                IconButton(onClick = onOpenAspect, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.AspectRatio, contentDescription = stringResource(R.string.aspect_ratio_title), tint = Color.White)
                }
                IconButton(onClick = onRotate, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.ScreenRotation, contentDescription = stringResource(R.string.cd_rotate), tint = Color.White)
                }
            }
        }
    }
}
