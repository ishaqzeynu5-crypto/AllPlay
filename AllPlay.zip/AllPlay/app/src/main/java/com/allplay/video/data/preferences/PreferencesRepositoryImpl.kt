package com.allplay.video.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.allplay.video.domain.model.*
import com.allplay.video.domain.repository.PreferencesRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "allplay_prefs")

@Singleton
class PreferencesRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : PreferencesRepository {

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val SORT_OPTION = stringPreferencesKey("sort_option")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val VIEW_MODE = stringPreferencesKey("view_mode")
        val DECODER_MODE = stringPreferencesKey("decoder_mode")
        val BACKGROUND_AUDIO = booleanPreferencesKey("background_audio")
        val SUB_FONT_SIZE = floatPreferencesKey("sub_font_size")
        val SUB_TEXT_COLOR = intPreferencesKey("sub_text_color")
        val SUB_BG_COLOR = intPreferencesKey("sub_bg_color")
    }

    override val userPreferences: Flow<UserPreferences> = context.dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs ->
            UserPreferences(
                onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
                themeMode = runCatching { ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: "") }
                    .getOrDefault(ThemeMode.SYSTEM),
                language = runCatching { AppLanguage.valueOf(prefs[Keys.LANGUAGE] ?: "") }
                    .getOrDefault(AppLanguage.ENGLISH),
                sortOption = runCatching { SortOption.valueOf(prefs[Keys.SORT_OPTION] ?: "") }
                    .getOrDefault(SortOption.DATE),
                sortOrder = runCatching { SortOrder.valueOf(prefs[Keys.SORT_ORDER] ?: "") }
                    .getOrDefault(SortOrder.DESCENDING),
                viewMode = runCatching { ViewMode.valueOf(prefs[Keys.VIEW_MODE] ?: "") }
                    .getOrDefault(ViewMode.LIST),
                decoderMode = runCatching { DecoderMode.valueOf(prefs[Keys.DECODER_MODE] ?: "") }
                    .getOrDefault(DecoderMode.AUTO_HW_FIRST),
                backgroundAudioEnabled = prefs[Keys.BACKGROUND_AUDIO] ?: false,
                subtitleStyle = SubtitleStyle(
                    fontSizeSp = prefs[Keys.SUB_FONT_SIZE] ?: 20f,
                    textColorArgb = prefs[Keys.SUB_TEXT_COLOR] ?: 0xFFFFFFFF.toInt(),
                    backgroundColorArgb = prefs[Keys.SUB_BG_COLOR] ?: 0x80000000.toInt()
                )
            )
        }

    override suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    override suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    override suspend fun setSort(option: SortOption, order: SortOrder) {
        context.dataStore.edit {
            it[Keys.SORT_OPTION] = option.name
            it[Keys.SORT_ORDER] = order.name
        }
    }

    override suspend fun setViewMode(mode: ViewMode) {
        context.dataStore.edit { it[Keys.VIEW_MODE] = mode.name }
    }

    override suspend fun setDecoderMode(mode: DecoderMode) {
        context.dataStore.edit { it[Keys.DECODER_MODE] = mode.name }
    }

    override suspend fun setBackgroundAudioEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BACKGROUND_AUDIO] = enabled }
    }

    override suspend fun updateSubtitleStyle(style: SubtitleStyle) {
        context.dataStore.edit {
            it[Keys.SUB_FONT_SIZE] = style.fontSizeSp
            it[Keys.SUB_TEXT_COLOR] = style.textColorArgb
            it[Keys.SUB_BG_COLOR] = style.backgroundColorArgb
        }
    }
}
