package com.allplay.video.player

import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import com.allplay.video.domain.model.SubtitleStyle

/**
 * Applies user-selected subtitle font size, text color, and background style directly
 * to Media3's SubtitleView.
 */
object SubtitleStyleHelper {

    @OptIn(UnstableApi::class)
    fun applyTo(subtitleView: SubtitleView?, style: SubtitleStyle) {
        if (subtitleView == null) return
        subtitleView.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, style.fontSizeSp)
        val captionStyle = CaptionStyleCompat(
            style.textColorArgb,
            style.backgroundColorArgb,
            Color.TRANSPARENT,
            CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
            Color.BLACK,
            Typeface.DEFAULT_BOLD
        )
        subtitleView.setStyle(captionStyle)
        subtitleView.setApplyEmbeddedStyles(false)
    }
}
