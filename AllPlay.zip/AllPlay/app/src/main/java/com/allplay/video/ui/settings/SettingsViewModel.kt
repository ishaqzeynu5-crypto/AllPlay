package com.allplay.video.ui.settings

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.allplay.video.domain.model.*
import com.allplay.video.domain.repository.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    val preferences: StateFlow<UserPreferences> = preferencesRepository.userPreferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserPreferences())

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferencesRepository.setThemeMode(mode) }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            preferencesRepository.setLanguage(language)
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(language.tag))
        }
    }

    fun setDecoderMode(mode: DecoderMode) {
        viewModelScope.launch { preferencesRepository.setDecoderMode(mode) }
    }

    fun setBackgroundAudio(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setBackgroundAudioEnabled(enabled) }
    }

    fun setOnboardingCompleted(completed: Boolean) {
        viewModelScope.launch { preferencesRepository.setOnboardingCompleted(completed) }
    }
}
