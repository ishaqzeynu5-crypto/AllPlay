package com.allplay.video.data.scanner

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import androidx.media3.common.MimeTypes
import com.allplay.video.domain.model.ExternalSubtitle
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Auto-detects external subtitle files (.srt, .ass, .ssa, .vtt) sharing the same base name
 * as the video file in the same folder, and maps subtitle extensions to Media3 MIME types.
 */
@Singleton
class SubtitleAutoDetector @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val subtitleExtensions = listOf("srt", "ass", "ssa", "vtt")

    suspend fun findMatchingSubtitles(
        videoUri: String,
        folderPath: String,
        displayName: String
    ): List<ExternalSubtitle> = withContext(Dispatchers.IO) {
        val baseName = displayName.substringBeforeLast('.').ifBlank { return@withContext emptyList() }
        val results = mutableListOf<ExternalSubtitle>()

        // Resolve physical folder when accessible (e.g., Movies/, Download/, or direct file:// path)
        val directory: File? = when {
            videoUri.startsWith("file://") -> Uri.parse(videoUri).path?.let { File(it).parentFile }
            folderPath.startsWith("/") -> File(folderPath)
            folderPath.isNotBlank() -> File(Environment.getExternalStorageDirectory(), folderPath)
            else -> null
        }

        if (directory != null && directory.exists() && directory.isDirectory) {
            directory.listFiles()?.forEach { file ->
                if (!file.isFile) return@forEach
                val ext = file.extension.lowercase()
                if (ext !in subtitleExtensions) return@forEach
                val fileBase = file.nameWithoutExtension
                // Match exact name (Movie.srt) or language-tagged name (Movie.en.srt, Movie.am.srt)
                if (fileBase.equals(baseName, ignoreCase = true) ||
                    fileBase.startsWith("$baseName.", ignoreCase = true)
                ) {
                    val langTag = fileBase.removePrefix(baseName).trimStart('.').ifBlank { null }
                    results.add(
                        ExternalSubtitle(
                            uri = Uri.fromFile(file).toString(),
                            label = file.name,
                            mimeType = mimeTypeForExtension(ext),
                            language = langTag
                        )
                    )
                }
            }
        }
        results
    }

    fun buildExternalSubtitleFromUri(uri: Uri): ExternalSubtitle {
        val name = queryDisplayName(uri) ?: uri.lastPathSegment ?: "External Subtitle"
        val ext = name.substringAfterLast('.', "srt").lowercase()
        return ExternalSubtitle(
            uri = uri.toString(),
            label = name,
            mimeType = mimeTypeForExtension(ext),
            language = null
        )
    }

    fun mimeTypeForExtension(ext: String): String = when (ext.lowercase()) {
        "srt" -> MimeTypes.APPLICATION_SUBRIP
        "ass", "ssa" -> MimeTypes.TEXT_SSA
        "vtt" -> MimeTypes.TEXT_VTT
        else -> MimeTypes.APPLICATION_SUBRIP
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
        } catch (_: Exception) {
            null
        }
    }
}
