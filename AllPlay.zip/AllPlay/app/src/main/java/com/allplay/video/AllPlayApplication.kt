package com.allplay.video

import android.app.Application
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.disk.DiskCache
import coil3.memory.MemoryCache
import coil3.request.crossfade
import coil3.video.VideoFrameDecoder
import dagger.hilt.android.HiltAndroidApp
import okio.Path.Companion.toOkioPath

/**
 * Application entry point configuring Hilt and a memory-tuned Coil 3 ImageLoader
 * with VideoFrameDecoder for smooth thumbnail scrolling across 10,000+ videos.
 */
@HiltAndroidApp
class AllPlayApplication : Application(), SingletonImageLoader.Factory {

    override fun newImageLoader(context: PlatformContext): ImageLoader {
        return ImageLoader.Builder(context)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .memoryCache {
                MemoryCache.Builder()
                    .maxSizePercent(context, 0.20)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("video_thumbs").toOkioPath())
                    .maxSizeBytes(150L * 1024L * 1024L) // 150 MB thumbnail disk cache
                    .build()
            }
            .crossfade(true)
            .build()
    }
}
