package com.allplay.video.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.allplay.video.domain.model.*
import com.allplay.video.domain.repository.PreferencesRepository
import com.allplay.video.domain.repository.VideoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class HomeTab { VIDEOS, FOLDERS, RECENT }

data class HomeUiState(
    val selectedTab: HomeTab = HomeTab.VIDEOS,
    val searchQuery: String = "",
    val selectedFolderPath: String? = null,
    val videos: List<VideoItem> = emptyList(),
    val folders: List<VideoFolder> = emptyList(),
    val continueWatching: List<VideoItem> = emptyList(),
    val recentVideos: List<VideoItem> = emptyList(),
    val sortOption: SortOption = SortOption.DATE,
    val sortOrder: SortOrder = SortOrder.DESCENDING,
    val viewMode: ViewMode = ViewMode.LIST,
    val isLoading: Boolean = true
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val videoRepository: VideoRepository,
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    private val selectedTab = MutableStateFlow(HomeTab.VIDEOS)
    private val searchQuery = MutableStateFlow("")
    private val selectedFolderPath = MutableStateFlow<String?>(null)
    private val isLoading = MutableStateFlow(true)

    val uiState: StateFlow<HomeUiState> = combine(
        videoRepository.observeAllVideos(),
        videoRepository.observeFolders(),
        videoRepository.observeContinueWatching(),
        videoRepository.observeRecentVideos(),
        preferencesRepository.userPreferences,
        selectedTab,
        searchQuery,
        selectedFolderPath,
        isLoading
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val allVideos = values[0] as List<VideoItem>
        @Suppress("UNCHECKED_CAST")
        val folders = values[1] as List<VideoFolder>
        @Suppress("UNCHECKED_CAST")
        val continueWatching = values[2] as List<VideoItem>
        @Suppress("UNCHECKED_CAST")
        val recentVideos = values[3] as List<VideoItem>
        val prefs = values[4] as UserPreferences
        val tab = values[5] as HomeTab
        val query = values[6] as String
        val folderPath = values[7] as String?
        val loading = values[8] as Boolean

        val filtered = allVideos
            .filter { video ->
                val matchesFolder = folderPath == null ||
                    video.folderPath.ifBlank { video.folderName } == folderPath
                val matchesQuery = query.isBlank() ||
                    video.title.contains(query, ignoreCase = true) ||
                    video.displayName.contains(query, ignoreCase = true)
                matchesFolder && matchesQuery
            }
            .sortByPreference(prefs.sortOption, prefs.sortOrder)

        HomeUiState(
            selectedTab = tab,
            searchQuery = query,
            selectedFolderPath = folderPath,
            videos = filtered,
            folders = folders.filter {
                query.isBlank() || it.name.contains(query, ignoreCase = true)
            },
            continueWatching = continueWatching,
            recentVideos = recentVideos.filter {
                query.isBlank() || it.title.contains(query, ignoreCase = true)
            },
            sortOption = prefs.sortOption,
            sortOrder = prefs.sortOrder,
            viewMode = prefs.viewMode,
            isLoading = loading
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun refreshLibrary() {
        viewModelScope.launch {
            isLoading.value = true
            videoRepository.refreshLibrary()
            isLoading.value = false
        }
    }

    fun selectTab(tab: HomeTab) {
        selectedTab.value = tab
        if (tab != HomeTab.FOLDERS) selectedFolderPath.value = null
    }

    fun updateSearch(query: String) {
        searchQuery.value = query
    }

    fun openFolder(folderPath: String?) {
        selectedFolderPath.value = folderPath
    }

    fun setSort(option: SortOption, order: SortOrder) {
        viewModelScope.launch { preferencesRepository.setSort(option, order) }
    }

    fun toggleViewMode() {
        viewModelScope.launch {
            val next = if (uiState.value.viewMode == ViewMode.LIST) ViewMode.GRID else ViewMode.LIST
            preferencesRepository.setViewMode(next)
        }
    }

    private fun List<VideoItem>.sortByPreference(
        option: SortOption,
        order: SortOrder
    ): List<VideoItem> {
        val comparator = when (option) {
            SortOption.NAME -> compareBy<VideoItem> { it.title.lowercase() }
            SortOption.DATE -> compareBy<VideoItem> { it.dateAddedSec }
            SortOption.SIZE -> compareBy<VideoItem> { it.sizeBytes }
            SortOption.DURATION -> compareBy<VideoItem> { it.durationMs }
        }
        return if (order == SortOrder.ASCENDING) sortedWith(comparator)
        else sortedWith(comparator.reversed())
    }
}
