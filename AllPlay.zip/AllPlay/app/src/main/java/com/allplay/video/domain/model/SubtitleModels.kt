package com.allplay.video.domain.model

/**
 * Represents an external subtitle file (.srt, .ass, .ssa, .vtt) detected or picked by the user.
 */
data class ExternalSubtitle(
    val uri: String,
    val label: String,
    val mimeType: String,
    val language: String? = null
)

/**
 * Represents a selectable audio or embedded subtitle track exposed by Media3 Tracks.
 */
data class TrackInfo(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val language: String?,
    val isSelected: Boolean
)

/**
 * User-customizable subtitle appearance and timing settings.
 */
data class SubtitleStyle(
    val fontSizeSp: Float = 20f,
    val textColorArgb: Int = 0xFFFFFFFF.toInt(),
    val backgroundColorArgb: Int = 0x80000000.toInt(), // Semi-transparent black
    val delayMs: Long = 0L
)
