package com.allplay.video.player

import android.content.Context
import androidx.media3.exoplayer.ExoPlayer
import com.allplay.video.domain.model.DecoderMode

/**
 * Shares a single active ExoPlayer instance between PlayerViewModel and PlaybackService
 * so background audio playback continues seamlessly when the user leaves the app.
 */
object SharedPlayerHolder {
    @Volatile
    private var player: ExoPlayer? = null
    private var activeMode: DecoderMode = DecoderMode.AUTO_HW_FIRST

    @Synchronized
    fun getOrCreate(context: Context, mode: DecoderMode): ExoPlayer {
        val existing = player
        if (existing != null && activeMode == mode) return existing
        existing?.release()
        activeMode = mode
        return DecoderFactory.createPlayer(context.applicationContext, mode).also {
            player = it
        }
    }

    @Synchronized
    fun rebuildWithMode(context: Context, mode: DecoderMode): ExoPlayer {
        player?.release()
        activeMode = mode
        return DecoderFactory.createPlayer(context.applicationContext, mode).also {
            player = it
        }
    }

    fun currentMode(): DecoderMode = activeMode

    @Synchronized
    fun release() {
        player?.release()
        player = null
    }
}
