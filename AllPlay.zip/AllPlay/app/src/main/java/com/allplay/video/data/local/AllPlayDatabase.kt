package com.allplay.video.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [PlaybackHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AllPlayDatabase : RoomDatabase() {
    abstract fun playbackHistoryDao(): PlaybackHistoryDao
}
