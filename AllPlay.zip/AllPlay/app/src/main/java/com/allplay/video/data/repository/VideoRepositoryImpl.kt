package com.allplay.video.data.repository

import com.allplay.video.data.local.PlaybackHistoryDao
import com.allplay.video.data.local.PlaybackHistoryEntity
import com.allplay.video.data.scanner.MediaStoreScanner
import com.allplay.video.domain.model.VideoFolder
import com.allplay.video.domain.model.VideoItem
import com.allplay.video.domain.repository.VideoRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VideoRepositoryImpl @Inject constructor(
    private val scanner: MediaStoreScanner,
    private val historyDao: PlaybackHistoryDao
) : VideoRepository {

    private val scannedVideos = MutableStateFlow<List<VideoItem>>(emptyList())

    override fun observeAllVideos(): Flow<List<VideoItem>> =
        combine(scannedVideos, historyDao.observeAllHistory()) { videos, history ->
            val historyMap = history.associateBy { it.uri }
            videos.map { video ->
                val saved = historyMap[video.uri]
                if (saved != null) {
                    video.copy(
                        lastPositionMs = saved.positionMs,
                        lastPlayedAt = saved.lastPlayedAt
                    )
                } else video
            }
        }

    override fun observeContinueWatching(): Flow<List<VideoItem>> =
        observeAllVideos().map { videos ->
            videos.filter { it.isInProgress }
                .sortedByDescending { it.lastPlayedAt }
                .take(15)
        }

    override fun observeRecentVideos(): Flow<List<VideoItem>> =
        combine(scannedVideos, historyDao.observeAllHistory()) { videos, history ->
            val videoByUri = videos.associateBy { it.uri }
            history.map { entry ->
                val local = videoByUri[entry.uri]
                local?.copy(
                    lastPositionMs = entry.positionMs,
                    lastPlayedAt = entry.lastPlayedAt
                ) ?: VideoItem(
                    id = entry.uri.hashCode().toLong(),
                    uri = entry.uri,
                    title = entry.title,
                    displayName = entry.title,
                    folderName = "Stream / External",
                    folderPath = "",
                    durationMs = entry.durationMs,
                    sizeBytes = 0L,
                    dateAddedSec = entry.lastPlayedAt / 1000L,
                    lastPositionMs = entry.positionMs,
                    lastPlayedAt = entry.lastPlayedAt
                )
            }
        }

    override fun observeFolders(): Flow<List<VideoFolder>> =
        scannedVideos.map { videos ->
            videos.groupBy { it.folderPath.ifBlank { it.folderName } }
                .map { (path, items) ->
                    VideoFolder(
                        name = items.first().folderName,
                        path = path,
                        videoCount = items.size,
                        totalSizeBytes = items.sumOf { it.sizeBytes },
                        previewUri = items.first().uri
                    )
                }
                .sortedBy { it.name.lowercase() }
        }

    override suspend fun refreshLibrary() {
        scannedVideos.value = scanner.scanVideos()
    }

    override suspend fun getSavedPosition(uri: String): Long =
        historyDao.getByUri(uri)?.positionMs ?: 0L

    override suspend fun getSavedSpeed(uri: String): Float =
        historyDao.getByUri(uri)?.playbackSpeed ?: 1.0f

    override suspend fun savePlaybackProgress(
        uri: String,
        title: String,
        positionMs: Long,
        durationMs: Long,
        playbackSpeed: Float
    ) {
        val safePos = if (durationMs > 0L && positionMs >= durationMs - 3_000L) 0L else positionMs
        historyDao.upsert(
            PlaybackHistoryEntity(
                uri = uri,
                title = title,
                positionMs = safePos,
                durationMs = durationMs,
                lastPlayedAt = System.currentTimeMillis(),
                playbackSpeed = playbackSpeed
            )
        )
    }
}
