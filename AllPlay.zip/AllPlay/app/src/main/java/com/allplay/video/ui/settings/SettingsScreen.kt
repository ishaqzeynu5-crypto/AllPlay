package com.allplay.video.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.allplay.video.R
import com.allplay.video.domain.model.AppLanguage
import com.allplay.video.domain.model.DecoderMode
import com.allplay.video.domain.model.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onReplayTutorial: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.cd_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Theme selector
            Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                listOf(
                    ThemeMode.SYSTEM to R.string.theme_system,
                    ThemeMode.LIGHT to R.string.theme_light,
                    ThemeMode.DARK to R.string.theme_dark
                ).forEach { (mode, labelRes) ->
                    FilterChip(
                        selected = prefs.themeMode == mode,
                        onClick = { viewModel.setThemeMode(mode) },
                        label = { Text(stringResource(labelRes)) },
                        modifier = Modifier.weight(1f).height(48.dp)
                    )
                }
            }

            // Language selector (English / Amharic)
            Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = prefs.language == AppLanguage.ENGLISH,
                    onClick = { viewModel.setLanguage(AppLanguage.ENGLISH) },
                    label = { Text(stringResource(R.string.lang_english)) },
                    modifier = Modifier.weight(1f).height(48.dp)
                )
                FilterChip(
                    selected = prefs.language == AppLanguage.AMHARIC,
                    onClick = { viewModel.setLanguage(AppLanguage.AMHARIC) },
                    label = { Text(stringResource(R.string.lang_amharic)) },
                    modifier = Modifier.weight(1f).height(48.dp)
                )
            }

            // Default Decoder selector
            Text(stringResource(R.string.settings_decoder), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = prefs.decoderMode == DecoderMode.AUTO_HW_FIRST,
                    onClick = { viewModel.setDecoderMode(DecoderMode.AUTO_HW_FIRST) },
                    label = { Text(stringResource(R.string.decoder_auto)) },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                )
                FilterChip(
                    selected = prefs.decoderMode == DecoderMode.SOFTWARE_FFMPEG,
                    onClick = { viewModel.setDecoderMode(DecoderMode.SOFTWARE_FFMPEG) },
                    label = { Text(stringResource(R.string.decoder_software_only)) },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                )
            }

            // Background audio switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.settings_bg_audio),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f).padding(end = 16.dp)
                )
                Switch(
                    checked = prefs.backgroundAudioEnabled,
                    onCheckedChange = viewModel::setBackgroundAudio
                )
            }

            // Replay 3-screen gesture tutorial
            OutlinedButton(
                onClick = onReplayTutorial,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.settings_replay_tutorial))
            }
        }
    }
}
