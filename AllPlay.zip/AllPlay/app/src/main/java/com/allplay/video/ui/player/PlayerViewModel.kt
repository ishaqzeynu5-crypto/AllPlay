package com.allplay.video.ui.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.annotation.OptIn
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.allplay.video.R
import com.allplay.video.data.scanner.SubtitleAutoDetector
import com.allplay.video.domain.model.*
import com.allplay.video.domain.repository.PreferencesRepository
import com.allplay.video.domain.repository.VideoRepository
import com.allplay.video.player.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PlayerUiState(
    val title: String = "",
    val uri: String = "",
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val aspectRatioMode: AspectRatioMode = AspectRatioMode.FIT,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HW_FIRST,
    val isUsingSoftwareFallback: Boolean = false,
    val isScreenLocked: Boolean = false,
    val backgroundAudioEnabled: Boolean = false,
    val audioTracks: List<TrackInfo> = emptyList(),
    val subtitleTracks: List<TrackInfo> = emptyList(),
    val externalSubtitles: List<ExternalSubtitle> = emptyList(),
    val subtitleStyle: SubtitleStyle = SubtitleStyle(),
    val sleepTimerState: SleepTimerState = SleepTimerState.Off,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
    @StringRes val statusBannerRes: Int? = null,
    @StringRes val errorBannerRes: Int? = null
)

@HiltViewModel
class PlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val videoRepository: VideoRepository,
    private val preferencesRepository: PreferencesRepository,
    private val subtitleAutoDetector: SubtitleAutoDetector
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val sleepTimerManager = SleepTimerManager(viewModelScope)
    private val _playerFlow = MutableStateFlow<ExoPlayer?>(null)
    val playerFlow: StateFlow<ExoPlayer?> = _playerFlow.asStateFlow()

    private var playlist: List<VideoItem> = emptyList()
    private var currentIndex: Int = 0
    private var progressJob: Job? = null
    private var attemptedSwFallback = false

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.update { it.copy(isPlaying = isPlaying) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val player = _playerFlow.value ?: return
            _uiState.update {
                it.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    durationMs = player.duration.coerceAtLeast(0L)
                )
            }
            if (playbackState == Player.STATE_ENDED) {
                saveCurrentProgress()
                if (sleepTimerManager.state.value is SleepTimerState.EndOfVideo) {
                    sleepTimerManager.cancel()
                    player.pause()
                } else if (currentIndex + 1 < playlist.size) {
                    playNext()
                }
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            updateTrackLists(tracks)
        }

        override fun onPlayerError(error: PlaybackException) {
            // Automatic fallback: Hardware decoder -> Software (FFmpeg) decoder on first decoder error
            if (PlayerErrorMapper.isDecoderError(error) &&
                !attemptedSwFallback &&
                SharedPlayerHolder.currentMode() != DecoderMode.SOFTWARE_FFMPEG
            ) {
                attemptedSwFallback = true
                _uiState.update {
                    it.copy(
                        statusBannerRes = R.string.error_trying_sw_decoder,
                        errorBannerRes = null,
                        isUsingSoftwareFallback = true,
                        decoderMode = DecoderMode.SOFTWARE_FFMPEG
                    )
                }
                rebuildAndResume(DecoderMode.SOFTWARE_FFMPEG)
            } else {
                _uiState.update {
                    it.copy(
                        statusBannerRes = null,
                        errorBannerRes = PlayerErrorMapper.toFriendlyMessageRes(error),
                        isPlaying = false,
                        isBuffering = false
                    )
                }
            }
        }
    }

    init {
        viewModelScope.launch {
            preferencesRepository.userPreferences.collect { prefs ->
                _uiState.update {
                    it.copy(
                        subtitleStyle = prefs.subtitleStyle,
                        backgroundAudioEnabled = prefs.backgroundAudioEnabled
                    )
                }
            }
        }
        viewModelScope.launch {
            sleepTimerManager.state.collect { timerState ->
                _uiState.update { it.copy(sleepTimerState = timerState) }
            }
        }
    }

    fun loadPlaylistAndPlay(items: List<VideoItem>, startIndex: Int) {
        if (items.isEmpty()) return
        playlist = items
        currentIndex = startIndex.coerceIn(0, items.lastIndex)
        playCurrentItem()
    }

    fun loadSingleUri(uri: String, title: String) {
        val single = VideoItem(
            id = uri.hashCode().toLong(),
            uri = uri,
            title = title,
            displayName = title,
            folderName = "",
            folderPath = "",
            durationMs = 0L,
            sizeBytes = 0L,
            dateAddedSec = System.currentTimeMillis() / 1000L
        )
        loadPlaylistAndPlay(listOf(single), 0)
    }

    private fun playCurrentItem() {
        val item = playlist.getOrNull(currentIndex) ?: return
        attemptedSwFallback = false

        viewModelScope.launch {
            val prefs = preferencesRepository.userPreferences.first()
            val savedPos = videoRepository.getSavedPosition(item.uri)
            val savedSpeed = videoRepository.getSavedSpeed(item.uri)
            val detectedSubs = subtitleAutoDetector.findMatchingSubtitles(
                videoUri = item.uri,
                folderPath = item.folderPath,
                displayName = item.displayName
            )

            _uiState.update {
                it.copy(
                    title = item.title,
                    uri = item.uri,
                    playbackSpeed = savedSpeed,
                    decoderMode = prefs.decoderMode,
                    isUsingSoftwareFallback = prefs.decoderMode == DecoderMode.SOFTWARE_FFMPEG,
                    externalSubtitles = detectedSubs,
                    hasNext = currentIndex < playlist.lastIndex,
                    hasPrevious = currentIndex > 0,
                    statusBannerRes = null,
                    errorBannerRes = null
                )
            }

            preparePlayer(
                uri = item.uri,
                title = item.title,
                startPositionMs = savedPos,
                speed = savedSpeed,
                mode = prefs.decoderMode,
                subtitles = detectedSubs
            )
        }
    }

    private fun rebuildAndResume(newMode: DecoderMode) {
        val state = _uiState.value
        val resumePos = _playerFlow.value?.currentPosition?.coerceAtLeast(0L) ?: state.currentPositionMs
        preparePlayer(
            uri = state.uri,
            title = state.title,
            startPositionMs = resumePos,
            speed = state.playbackSpeed,
            mode = newMode,
            subtitles = state.externalSubtitles
        )
    }

    private fun preparePlayer(
        uri: String,
        title: String,
        startPositionMs: Long,
        speed: Float,
        mode: DecoderMode,
        subtitles: List<ExternalSubtitle>
    ) {
        _playerFlow.value?.removeListener(playerListener)
        val player = SharedPlayerHolder.rebuildWithMode(context, mode)
        player.addListener(playerListener)
        _playerFlow.value = player

        val subtitleConfigs = subtitles.map { sub ->
            MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub.uri))
                .setMimeType(sub.mimeType)
                .setLabel(sub.label)
                .setLanguage(sub.language)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
        }

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(uri))
            .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
            .setSubtitleConfigurations(subtitleConfigs)
            .build()

        player.setMediaItem(mediaItem, startPositionMs)
        player.setPlaybackSpeed(speed)
        player.prepare()
        player.playWhenReady = true
        startProgressTicker()
    }

    private fun startProgressTicker() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            var ticks = 0
            while (true) {
                val player = _playerFlow.value
                if (player != null) {
                    val pos = player.currentPosition.coerceAtLeast(0L)
                    val dur = player.duration.coerceAtLeast(0L)
                    _uiState.update {
                        it.copy(
                            currentPositionMs = pos,
                            durationMs = dur,
                            // Clear transient "Trying another decoder" banner once playback begins
                            statusBannerRes = if (player.isPlaying) null else it.statusBannerRes
                        )
                    }
                    if (++ticks % 10 == 0 && player.isPlaying) {
                        saveCurrentProgress()
                    }
                }
                delay(500L)
            }
        }
    }

    fun togglePlayPause() {
        val player = _playerFlow.value ?: return
        if (player.isPlaying) {
            player.pause()
            saveCurrentProgress()
        } else {
            player.play()
        }
    }

    fun seekTo(positionMs: Long) {
        val player = _playerFlow.value ?: return
        val clamped = positionMs.coerceIn(0L, player.duration.coerceAtLeast(0L))
        player.seekTo(clamped)
        _uiState.update { it.copy(currentPositionMs = clamped) }
    }

    fun seekBy(deltaMs: Long) {
        val player = _playerFlow.value ?: return
        seekTo(player.currentPosition + deltaMs)
    }

    fun playNext() {
        if (currentIndex + 1 < playlist.size) {
            saveCurrentProgress()
            currentIndex++
            playCurrentItem()
        }
    }

    fun playPrevious() {
        if (currentIndex > 0) {
            saveCurrentProgress()
            currentIndex--
            playCurrentItem()
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.25f, 4.0f)
        _playerFlow.value?.setPlaybackSpeed(clamped)
        _uiState.update { it.copy(playbackSpeed = clamped) }
    }

    fun setAspectRatio(mode: AspectRatioMode) {
        _uiState.update { it.copy(aspectRatioMode = mode) }
    }

    fun toggleScreenLock() {
        _uiState.update { it.copy(isScreenLocked = !it.isScreenLocked) }
    }

    fun toggleBackgroundAudio() {
        val next = !_uiState.value.backgroundAudioEnabled
        _uiState.update { it.copy(backgroundAudioEnabled = next) }
        viewModelScope.launch { preferencesRepository.setBackgroundAudioEnabled(next) }
        if (next) {
            context.startService(Intent(context, PlaybackService::class.java))
        }
    }

    fun switchDecoderManually(mode: DecoderMode) {
        attemptedSwFallback = mode == DecoderMode.SOFTWARE_FFMPEG
        _uiState.update {
            it.copy(
                decoderMode = mode,
                isUsingSoftwareFallback = mode == DecoderMode.SOFTWARE_FFMPEG,
                errorBannerRes = null
            )
        }
        rebuildAndResume(mode)
    }

    fun retryPlayback() {
        _uiState.update { it.copy(errorBannerRes = null) }
        rebuildAndResume(_uiState.value.decoderMode)
    }

    fun addExternalSubtitle(uri: Uri) {
        val sub = subtitleAutoDetector.buildExternalSubtitleFromUri(uri)
        val updated = _uiState.value.externalSubtitles + sub
        _uiState.update { it.copy(externalSubtitles = updated) }
        rebuildAndResume(_uiState.value.decoderMode)
    }

    fun updateSubtitleStyle(style: SubtitleStyle) {
        _uiState.update { it.copy(subtitleStyle = style) }
        viewModelScope.launch { preferencesRepository.updateSubtitleStyle(style) }
    }

    @OptIn(UnstableApi::class)
    fun selectAudioTrack(groupIndex: Int, trackIndex: Int) {
        val player = _playerFlow.value ?: return
        val group = player.currentTracks.groups.getOrNull(groupIndex) ?: return
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
            .build()
    }

    @OptIn(UnstableApi::class)
    fun selectSubtitleTrack(groupIndex: Int?, trackIndex: Int?) {
        val player = _playerFlow.value ?: return
        val builder = player.trackSelectionParameters.buildUpon()
        if (groupIndex == null || trackIndex == null) {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            val group = player.currentTracks.groups.getOrNull(groupIndex) ?: return
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            builder.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
        }
        player.trackSelectionParameters = builder.build()
    }

    fun setSleepTimerMinutes(minutes: Int) {
        if (minutes <= 0) {
            sleepTimerManager.cancel()
        } else {
            sleepTimerManager.startMinutes(minutes) {
                _playerFlow.value?.pause()
                saveCurrentProgress()
            }
        }
    }

    fun setSleepTimerEndOfVideo() {
        sleepTimerManager.setEndOfVideo()
    }

    fun onAppBackgrounded(isInPip: Boolean) {
        saveCurrentProgress()
        if (!isInPip && !_uiState.value.backgroundAudioEnabled) {
            _playerFlow.value?.pause()
        } else if (_uiState.value.backgroundAudioEnabled && _uiState.value.isPlaying) {
            context.startService(Intent(context, PlaybackService::class.java))
        }
    }

    fun saveCurrentProgress() {
        val player = _playerFlow.value ?: return
        val state = _uiState.value
        if (state.uri.isBlank()) return
        val pos = player.currentPosition.coerceAtLeast(0L)
        val dur = player.duration.coerceAtLeast(0L)
        viewModelScope.launch {
            videoRepository.savePlaybackProgress(
                uri = state.uri,
                title = state.title,
                positionMs = pos,
                durationMs = dur,
                playbackSpeed = state.playbackSpeed
            )
        }
    }

    private fun updateTrackLists(tracks: Tracks) {
        val audio = mutableListOf<TrackInfo>()
        val subs = mutableListOf<TrackInfo>()
        tracks.groups.forEachIndexed { gIdx, group ->
            for (tIdx in 0 until group.length) {
                if (!group.isTrackSupported(tIdx)) continue
                val fmt = group.getTrackFormat(tIdx)
                val label = fmt.label ?: fmt.language?.uppercase() ?: "Track ${tIdx + 1}"
                val info = TrackInfo(
                    groupIndex = gIdx,
                    trackIndex = tIdx,
                    label = label,
                    language = fmt.language,
                    isSelected = group.isTrackSelected(tIdx)
                )
                when (group.type) {
                    C.TRACK_TYPE_AUDIO -> audio.add(info)
                    C.TRACK_TYPE_TEXT -> subs.add(info)
                }
            }
        }
        _uiState.update { it.copy(audioTracks = audio, subtitleTracks = subs) }
    }

    override fun onCleared() {
        saveCurrentProgress()
        progressJob?.cancel()
        _playerFlow.value?.removeListener(playerListener)
        if (!_uiState.value.backgroundAudioEnabled) {
            SharedPlayerHolder.release()
        }
        super.onCleared()
    }
}
