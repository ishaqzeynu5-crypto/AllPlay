package com.allplay.video.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import com.allplay.video.domain.model.DecoderMode
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory

/**
 * Builds Media3 ExoPlayer instances backed by NextLib's FFmpeg & dav1d software decoders.
 *
 * - AUTO_HW_FIRST uses EXTENSION_RENDERER_MODE_ON (Hardware decoder first, FFmpeg for unsupported codecs).
 * - SOFTWARE_FFMPEG uses EXTENSION_RENDERER_MODE_PREFER (FFmpeg software decoder preferred)
 *   which is also triggered automatically when hardware decoding throws a PlaybackException.
 */
object DecoderFactory {

    @OptIn(UnstableApi::class)
    fun createPlayer(context: Context, decoderMode: DecoderMode): ExoPlayer {
        val extensionMode = when (decoderMode) {
            DecoderMode.AUTO_HW_FIRST -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
            DecoderMode.SOFTWARE_FFMPEG -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
        }

        val renderersFactory = NextRenderersFactory(context)
            .setExtensionRendererMode(extensionMode)
            .setEnableDecoderFallback(true)

        // Enable constant bitrate seeking & broad TS/MPEG/MKV/AVI/FLV/OGV extraction
        val extractorsFactory = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES)

        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
            .setUserAgent("AllPlay/1.0 (Android; Media3)")

        val dataSourceFactory = DefaultDataSource.Factory(context, httpFactory)

        // DefaultMediaSourceFactory automatically routes HLS (.m3u8), DASH (.mpd), RTSP, and progressive files
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        return ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
    }
}
