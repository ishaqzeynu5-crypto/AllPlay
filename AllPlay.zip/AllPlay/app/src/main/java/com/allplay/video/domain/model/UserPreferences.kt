package com.allplay.video.domain.model

data class UserPreferences(
    val onboardingCompleted: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val sortOption: SortOption = SortOption.DATE,
    val sortOrder: SortOrder = SortOrder.DESCENDING,
    val viewMode: ViewMode = ViewMode.LIST,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HW_FIRST,
    val backgroundAudioEnabled: Boolean = false,
    val subtitleStyle: SubtitleStyle = SubtitleStyle()
)
