package com.allplay.video.ui.navigation

import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.allplay.video.ui.home.HomeScreen
import com.allplay.video.ui.onboarding.OnboardingScreen
import com.allplay.video.ui.player.PlayerScreen
import com.allplay.video.ui.player.PlayerViewModel
import com.allplay.video.ui.settings.SettingsScreen
import com.allplay.video.ui.settings.SettingsViewModel

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val PLAYER = "player"
    const val SETTINGS = "settings"
}

@Composable
fun AllPlayNavGraph(
    externalVideoUri: String?,
    externalVideoTitle: String?,
    onExternalIntentHandled: () -> Unit,
    isInPipMode: Boolean,
    onEnterPip: () -> Unit,
    onPlayerScreenActiveChanged: (Boolean) -> Unit
) {
    val navController = rememberNavController()
    val settingsViewModel: SettingsViewModel = hiltViewModel()
    val playerViewModel: PlayerViewModel = hiltViewModel()
    val prefs by settingsViewModel.preferences.collectAsStateWithLifecycle()

    // Automatically open PlayerScreen when launched from another app ("Open with")
    LaunchedEffect(externalVideoUri) {
        if (!externalVideoUri.isNullOrBlank()) {
            playerViewModel.loadSingleUri(
                uri = externalVideoUri,
                title = externalVideoTitle ?: "Video"
            )
            onExternalIntentHandled()
            navController.navigate(Routes.PLAYER) {
                launchSingleTop = true
            }
        }
    }

    val startDestination = if (prefs.onboardingCompleted) Routes.HOME else Routes.ONBOARDING

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Routes.ONBOARDING) {
            LaunchedEffect(Unit) { onPlayerScreenActiveChanged(false) }
            OnboardingScreen(
                onFinished = {
                    settingsViewModel.setOnboardingCompleted(true)
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            LaunchedEffect(Unit) { onPlayerScreenActiveChanged(false) }
            HomeScreen(
                onPlayVideo = { video, playlist ->
                    val idx = playlist.indexOfFirst { it.uri == video.uri }.coerceAtLeast(0)
                    playerViewModel.loadPlaylistAndPlay(playlist, idx)
                    navController.navigate(Routes.PLAYER)
                },
                onPlayUri = { uri, title ->
                    playerViewModel.loadSingleUri(uri, title)
                    navController.navigate(Routes.PLAYER)
                },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(Routes.PLAYER) {
            LaunchedEffect(Unit) { onPlayerScreenActiveChanged(true) }
            PlayerScreen(
                viewModel = playerViewModel,
                isInPipMode = isInPipMode,
                onEnterPip = onEnterPip,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            LaunchedEffect(Unit) { onPlayerScreenActiveChanged(false) }
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onReplayTutorial = {
                    navController.navigate(Routes.ONBOARDING)
                }
            )
        }
    }
}
