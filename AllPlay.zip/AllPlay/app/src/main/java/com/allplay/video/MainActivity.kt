package com.allplay.video

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.allplay.video.ui.navigation.AllPlayNavGraph
import com.allplay.video.ui.settings.SettingsViewModel
import com.allplay.video.ui.theme.AllPlayTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-Activity host extending AppCompatActivity so per-app English/Amharic locale
 * switching works seamlessly across all Android versions, with built-in PiP & "Open with" support.
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val externalUriState = mutableStateOf<String?>(null)
    private val externalTitleState = mutableStateOf<String?>(null)
    private val isInPipModeState = mutableStateOf(false)
    private var isPlayerScreenActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        setContent {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            val prefs by settingsViewModel.preferences.collectAsStateWithLifecycle()

            AllPlayTheme(themeMode = prefs.themeMode) {
                AllPlayNavGraph(
                    externalVideoUri = externalUriState.value,
                    externalVideoTitle = externalTitleState.value,
                    onExternalIntentHandled = {
                        externalUriState.value = null
                        externalTitleState.value = null
                    },
                    isInPipMode = isInPipModeState.value,
                    onEnterPip = { enterPip() },
                    onPlayerScreenActiveChanged = { active -> isPlayerScreenActive = active }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isPlayerScreenActive) {
            enterPip()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipModeState.value = isInPictureInPictureMode
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            val uri = intent.data ?: return
            externalUriState.value = uri.toString()
            externalTitleState.value = uri.lastPathSegment?.substringAfterLast('/') ?: "Video"
        }
    }
}
