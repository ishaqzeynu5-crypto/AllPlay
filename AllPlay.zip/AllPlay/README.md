# AllPlay — Universal Android Video Player

A production-quality, MX-Player-style Android video player built with **Kotlin**, **Jetpack Compose**, **Material 3**, **Media3 ExoPlayer 1.11.1**, and **NextLib FFmpeg (`nextlib-media3ext:1.11.1-0.16.0`)**.

## Key Architecture & Libraries

- **Playback Engine**: [AndroidX Media3 1.11.1](https://developer.android.com/jetpack/androidx/releases/media3) (`exoplayer`, `hls`, `dash`, `rtsp`, `ui`, `session`, `datasource`) + [NextLib Media3 FFmpeg Extension (`1.11.1-0.16.0`)](https://github.com/anilbeesetti/nextlib) for software decoding (AC3, EAC3, DTS, FLAC, OPUS, HEVC, VP8/VP9, AV1 via `dav1d`, MPEG-4, etc.) with automatic **Hardware -> Software fallback**.
- **UI & Accessibility**: [Jetpack Compose BOM 2026.09.00](https://developer.android.com/develop/ui/compose/bom) + Material 3 Dark/Light themes, 48dp–72dp touch targets, TalkBack semantics, English & Amharic (`values-am/strings.xml`) instant switching.
- **Data & DI**: [Hilt 2.60.1](https://mvnrepository.com/artifact/com.google.dagger/hilt-android), [Room 2.8.5](https://developer.android.com/jetpack/androidx/releases/room), Jetpack DataStore, and [Coil 3 (`3.6.3`)](https://coil-kt.github.io/coil/getting_started/) with `VideoFrameDecoder` disk/memory caching for smooth scrolling across 10,000+ videos.

## Step-by-Step Setup & Build Instructions

### Option A: Build Directly from Android Studio (Windows / macOS / Linux)

1. **Install Prerequisites**: Install [Android Studio](https://developer.android.com/studio) (Meerkat / Narwhal or newer) with **JDK 17** and **Android SDK Platform 35**.
2. **Unzip & Open**: Extract `AllPlay_Android_Video_Player.zip` and open the `AllPlay/` folder in Android Studio.
3. **Sync Gradle**: Wait for Gradle sync to download Media3 `1.11.1`, NextLib `1.11.1-0.16.0`, Hilt `2.60.1`, Room `2.8.5`, and Coil `3.6.3` from Google Maven & Maven Central.
4. **Run on Phone or Emulator**:
   - Enable **Developer Options -> USB Debugging** on your Android phone (Android 7.0 / API 24 or newer).
   - Connect via USB and click **Run ▶** in Android Studio, or run `./gradlew assembleDebug` to produce `app/build/outputs/apk/debug/app-debug.apk`.
5. **Release Build**:
   - In Android Studio, open **Build -> Generate Signed App Bundle / APK**.
   - Create/select your keystore and choose `release` (`isMinifyEnabled = true` with `proguard-rules.pro` already configured for Media3 & NextLib JNI classes).

### Option B: Build the APK from Your Phone via GitHub Actions (No Computer Needed)

1. Create a new repository on [GitHub](https://github.com/new) (e.g., `AllPlay`).
2. Upload the contents of the `AllPlay/` folder (including `.github/workflows/build-apk.yml`) to the `main` branch.
3. Open the **Actions** tab in your repository -> click **Build AllPlay Debug APK** -> click **Run workflow**.
4. Wait ~3–4 minutes for the green checkmark, then scroll down to **Artifacts** and download **`AllPlay-Debug-APK`**.
5. Unzip and tap `app-debug.apk` on your Android phone to install.
